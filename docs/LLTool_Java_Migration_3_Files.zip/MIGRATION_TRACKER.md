# LLTool Java Migration — Feature Tracker

## 1. Migration strategy

Migrate the existing LLTool product **one existing feature at a time**.

The Python application is the behavior reference. The Java application will use a modern native-feeling desktop UI, while preserving established workflows and functionality.

### Scope rule

- First: migrate existing features.
- Later: implement new features and enhancements.
- Do not bundle unrelated additions into a migration task.
- A screen built with mock data is a UI milestone, not a completed feature.

## 2. Status definitions

| Status | Meaning |
|---|---|
| `NOT_ANALYZED` | Python implementation has not been inspected. |
| `ANALYZED` | Existing behavior and dependencies documented. |
| `PLANNED` | Java scope and acceptance criteria agreed. |
| `UI_IN_PROGRESS` | Java UI implementation underway. |
| `UI_VERIFIED` | Layout and interactions reviewed; functionality may still be mocked. |
| `IMPLEMENTING` | Functional Java implementation underway. |
| `FUNCTIONALLY_VERIFIED` | Existing behavior and data effects tested. |
| `COMPLETE` | Acceptance criteria and regression checks passed. |
| `BLOCKED` | Waiting on a dependency or decision. |
| `DEFERRED` | Intentionally postponed. |
| `APPROVED_DEVIATION` | A behavior or design difference was explicitly approved. |

## 3. Migration phases

### Phase 0 — Source understanding and migration preparation
- [ ] Confirm the Python repository and current branch/version.
- [ ] Inspect the existing Java project and preserve any work already completed.
- [ ] Build a source inventory of screens, frontend handlers, API routes, backend services, database access, and persisted data.
- [ ] Record the current product's major workflows.
- [ ] Capture reference screenshots for major screens and states.
- [ ] Create a list of known defects, technical debt, and unanswered questions.
- [ ] Agree on the initial migration slice.

**Exit condition:** the team can identify the real source implementation for the first feature and explain its expected behavior.

### Phase 1 — Main desktop shell and visual foundation
- [ ] Reproduce the main application regions using JavaFX.
- [ ] Establish a modern native desktop visual system.
- [ ] Implement menus, toolbar, workspace regions, status area, and window behavior as applicable.
- [ ] Implement basic panel resizing and collapse/expand behavior.
- [ ] Verify layout at common window sizes.
- [ ] Use mock data only where needed to validate the UI.

**Exit condition:** the main shell feels like a coherent desktop application and provides the structural foundation for feature migration.

### Phase 2 — Core feature migration
Migrate each existing feature as a separate vertical slice. A suggested order is below; adjust it after source analysis and dependency mapping.

| Order | Feature | Python analysis | Java UI | Java behavior | Verification | Notes |
|---:|---|---|---|---|---|---|
| 1 | Connection management | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Saved connections, add/edit/delete, connect/disconnect |
| 2 | Object Explorer | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Tree, refresh, filtering, context actions |
| 3 | Query tabs and editor lifecycle | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Tab state, dirty state, connection context |
| 4 | Monaco editor integration | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Preserve required editor capabilities |
| 5 | Query execution | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Run, stop, parameters, errors |
| 6 | Results and Messages | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Multiple result sets, metadata, copy/export if supported |
| 7 | Execution Plan | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Preserve provider-specific behavior |
| 8 | Settings and themes | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Preserve existing settings and user preferences |
| 9 | Snippets and saved SQL | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Verify actual existing scope and persistence |
| 10 | Query history | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | Verify storage, search, and replay behavior |

### Phase 3 — Existing advanced workspaces
Only include a workspace after confirming it exists and is functional in the Python source.

| Feature / workspace | Python analysis | Java UI | Java behavior | Verification | Notes |
|---|---|---|---|---|---|
| Schema Compare | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Bravo Layout Compare | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Table Designer | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Table Data Editor | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Dependency Graph | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Object Content Search | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| SQL Visualizer | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Activity Monitor | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| User Permissions | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |
| Google Sheets integration | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | `NOT_ANALYZED` | |

### Phase 4 — Compatibility, regression, and release readiness
- [ ] Verify supported database providers and their feature differences.
- [ ] Verify user data import/compatibility.
- [ ] Run regression checks across migrated workflows.
- [ ] Review error handling and cancellation.
- [ ] Review performance with realistic result sizes.
- [ ] Review keyboard navigation and accessibility basics.
- [ ] Review packaging, startup, configuration, and logging.
- [ ] Document any approved deviations from Python behavior.

**Exit condition:** migrated functionality is stable, user data is protected, and known gaps are documented.

### Phase 5 — Future enhancements (after migration baseline)
New features belong here, not inside existing feature migration tasks.

| Enhancement | Priority | Status | Notes |
|---|---|---|---|
| To be defined after baseline migration | — | `DEFERRED` | Add only when requested and scoped |

## 4. Per-feature work record

Duplicate this section for each feature:

```markdown
## [Feature name]

- Status: `NOT_ANALYZED`
- Owner:
- Target milestone:

### Python reference
- Files:
- Functions / classes:
- API routes:
- Database / persistence:
- Reference screenshots:

### Existing behavior
- Main workflow:
- Validation:
- Error handling:
- State and side effects:
- Related features:

### Java implementation
- UI:
- Services:
- Data access:
- External dependencies:
- Mock data (if any):

### Acceptance criteria
- [ ] Existing main workflow works.
- [ ] Important edge cases are covered.
- [ ] Errors are handled and visible.
- [ ] Existing data semantics are preserved.
- [ ] UI follows the modern native desktop design system.
- [ ] No unrelated new feature was added.

### Verification
- Test cases:
- Manual checks:
- Screenshots / evidence:
- Known gaps:

### Deviations and decisions
- None / describe approved deviations.
```

## 5. Rules for declaring completion

A feature must not be marked `COMPLETE` if:
- It only has a visual shell.
- It uses mock data for a workflow that should be functional.
- Important actions are missing.
- Its Python behavior has not been inspected.
- Data effects or error paths have not been verified where relevant.
- Known differences have not been disclosed.

Use `UI_VERIFIED` for a completed visual prototype and keep functional status separate.

## 6. Migration decision log

| Date | Feature | Decision | Reason | Approved by |
|---|---|---|---|---|
| | | | | |

## 7. Known issues / questions

| Item | Type | Impact | Next action | Status |
|---|---|---|---|---|
| | | | | |

## 8. Final guiding principle

**Migrate the product that users already know, not an imagined replacement.**

Keep the workflows and capabilities that made LLTool useful. Rebuild them with Java technologies and present them through a cleaner, more native, modern desktop experience. Complete the existing baseline before expanding the product.
